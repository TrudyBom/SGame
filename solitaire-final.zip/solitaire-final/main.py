from src.SolitaireApp import SolitaireApp

if __name__ == "__main__":
    app = SolitaireApp()
    app.mainloop()
